<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Ramphastech</title>
    <meta   charset="UTF-8">
    <meta   name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;700&display=swap" rel="stylesheet">
    <link   href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link   href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;700&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;700&display=swap" rel="stylesheet">
    <link   rel="shortcut icon" type="img/pagina.png" href="./img/pagina.png">
    <style> 
        body{
            font-family: 'League Spartan', sans-serif;
            padding : 0;
            margin: 0;
            background-color: #fffff6;
            transition: background-color 0.3s, color 0.3s;
        }
        .navbar{
            width: 100%;
            min-width: 300px;
            background-color: #0197b2;
            margin: 0;  
        }
        .navbar img{
            width: 50px;
            height: 50px;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-sm">
        <div class="container-fluid">
            <div class="navbar-brand">Ramphastech</div>    
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="#inicio">Início</a></li>
                <li class="nav-item"><a class="nav-link" href="equipe.php">Equipe</a></li>
                <li class="nav-item"><a class="nav-link" href="#ideais">Ideais</a></li>
                <li class="nav-item"><a class="nav-link" href="#contato">Contato</a></li>
            </ul>
            <form class="d-flex">
                <button class="theme-toggle" id="theme-toggle">🌙</button>
                <img src="img/pagina.png" alt="Logo Tucano" class="logo">
            </form>
            </div>
        </div>
    </nav>
</body>
</html>