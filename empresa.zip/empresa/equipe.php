<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ramphastech</title>
    <link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" type="img/pagina.png" href="./img/pagina.png">
    <style>
        body {
            font-family: 'League Spartan', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #fffff6;
        }
        .navbar {
            background-color: #0197b2;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px 30px;
        }
        .logo-text {
            font-size: 35px;
            font-weight: 700;
            color: black;
        }
        .nav-links {
            list-style: none;
            display: flex;
            gap: 20px;
        }
        .nav-links a {
            font-size: 22px;
            font-weight: 600;
            text-decoration: none;
            color: black;
            padding: 5px;
            border-bottom: 2px solid transparent;
            transition: border-bottom 0.3s ease-in-out;
        }
        .nav-links a:hover {
            border-bottom: 2px solid black;
        }
        .logo {
            width: 75px;
            height: 75px;
        }
        .footer-content{
            text-align: center;
            padding: 20px;
            background-color: #0097b2;
            color: #000000;
            font-size: large;
        }
        .equipe-container {
            text-align: center;
            padding: 20px;
        }
        .equipe {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }
        .pessoa {
            background-color: white;
            border: 5px solid #0197b2;
            border-radius: 10px;
            padding: 15px;
            width: 200px;
            text-align: center;
            margin-left: 2vw;
            width: 20vw;
            height: 35vw;
        }
        .pessoa img {
            width: 300px;
            height: 300px;
            border-radius: 50%;
        }
        .pessoa h3 {
            margin: 10px 0 5px;
            font-size: 30px;
        }
        .pessoa p {
            font-size: 20px;
            color: #555;
        }
        @media (max-width: 768px) {
            .equipe {
                flex-direction: column;
                align-items: center;
            }
        }
    </style>
</head>
<body>
    <header class="navbar">
        <div class="logo-text">Ramphastech</div>
        <ul class="nav-links">
            <li><a href="index.php">Início</a></li>
            <li><a href="equipe.php">Equipe</a></li>
            <li><a href="index.php #ideais">Ideais</a></li>
            <li><a href="index.php #contato">Contato</a></li>
        </ul>
        <img src="img/pagina.png" alt="Logo Tucano" class="logo">
    </header>

    <section class="equipe-container">
        <h2>Nossa Equipe!</h2>
        <div class="equipe">
            <div class="pessoa">
                <img src="img/sara.jpg" alt="Sara">
                <h3>Sara Ribeiro</h3>
                <p>Desenvolvedora Front-End</p>
            </div>
            <div class="pessoa">
                <img src="img/pablo.jpg" alt="Pablo">
                <h3>Pablo Henrique</h3>
                <p>Desenvolvedor Front-End e Back-End</p>
                <p>pablo.l@aluno.ifsp.edu.br</p>
            </div>
            <div class="pessoa">
                <img src="img/fernanda.jpeg" alt="Fernanda">
                <h3>Maria Fernanda</h3>
                <p>Designer</p>
                <p>Desenvolvedora Front-End</p>
                <p>f.saugo@aluno.ifsp.edu.br</p>
            </div>
            <div class="pessoa">
                <img src="img/lucas.jfif" alt="Lucas">
                <h3>Lucas Siqueira</h3>
                <p>Gerente</p>
                <p>Desenvolvedor Back-End</p>
                <p>siqueira.lucassilva23@gmail.com</p>
            </div>
            <div class="pessoa">
                <img src="img/nuemo.jpeg" alt="Nuemo">
                <h3>Noemy Lima</h3>
                <p>Sub-Gerente e Designer Criativo</p>
                <p>Desenvolvedor Back-End</p>
                <p>noemy.lima@aluno.ifsp.edu.br</p>
                
            </div>
        </div>
    </section>

    <footer>
        <div class="footer-content">
            <p>&copy; 2025 Ramphastech. Todos os direitos reservados.</p>
            <img src="img/rodape.png" alt="Logo Tucano" class="logo">
        </div>
    </footer>
</body>
</html>
